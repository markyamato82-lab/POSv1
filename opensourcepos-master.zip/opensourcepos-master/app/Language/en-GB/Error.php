<?php

return [
    'no_permission_module'           => 'You do not have the permission to access the module named',
    'unable_to_create_env_file'      => 'Unable to create {filePath} to provision an environment key',
    'unable_to_lock_file'            => 'Unable to lock {filePath}: {reason}',
    'unable_to_open_lock_file'       => 'Unable to open {filePath}: {reason}',
    'unable_to_persist_throttle_key' => 'Unable to persist throttle.key to {filePath}',
    'unable_to_persist_encryption_key' => '',
    'encryption_key_not_provisioned' => '',
    'throttle_key_not_provisioned' => '',
    'unable_to_read_env_file'        => 'Unable to read {filePath} to provision an environment key',
    'unknown'                        => 'Unexpected error',
];
