<?php

namespace App\Controllers;

use App\Models\Module;
use CodeIgniter\HTTP\Exceptions\RedirectException;
use CodeIgniter\HTTP\ResponseInterface;
use Config\Services;

/**
 *
 *
 * @property module module
 *
 */
class Employees extends Persons
{
    public function __construct()
    {
        parent::__construct('employees');

        $this->module = model('Module');
    }

    /**
     * Returns employee table data rows. This will be called with AJAX.
     *
     * @return void
     */
    public function getSearch(): ResponseInterface
    {
        $search = $this->request->getGet('search');
        $limit  = $this->request->getGet('limit', FILTER_SANITIZE_NUMBER_INT);
        $offset = $this->request->getGet('offset', FILTER_SANITIZE_NUMBER_INT);
        $sort   = $this->sanitizeSortColumn(person_headers(), $this->request->getGet('sort', FILTER_SANITIZE_FULL_SPECIAL_CHARS), 'people.person_id');
        $order  = $this->request->getGet('order', FILTER_SANITIZE_FULL_SPECIAL_CHARS);

        $employees = $this->employee->search($search, $limit, $offset, $sort, $order);
        $total_rows = $this->employee->get_found_rows($search);

        $data_rows = [];
        foreach ($employees->getResult() as $person) {
            $data_rows[] = get_person_data_row($person);
        }

        return $this->response->setJSON(['total' => $total_rows, 'rows' => $data_rows]);
    }

    /**
     * AJAX called function gives search suggestions based on what is being searched for.
     *
     * @return ResponseInterface
     */
    public function getSuggest(): ResponseInterface
    {
        $search = $this->request->getGet('term');
        $suggestions = $this->employee->get_search_suggestions($search, 25, true);

        return $this->response->setJSON($suggestions);
    }

    /**
     * @return ResponseInterface
     */
    public function suggest_search(): ResponseInterface
    {
        $search = $this->request->getPost('term');
        $suggestions = $this->employee->get_search_suggestions($search);

        return $this->response->setJSON($suggestions);
    }

    /**
     * Loads the employee edit form
     * @return string
     */
    public function getView(int $employee_id = NEW_ENTRY): string
    {
        $person_info = $this->employee->get_info($employee_id);
        $current_user = $this->employee->get_logged_in_employee_info();

        if ($employee_id != NEW_ENTRY && !$this->employee->canModifyEmployee($person_info->person_id, $current_user->person_id)) {
            throw new RedirectException('no_access/employees/employees');
        }

        foreach (get_object_vars($person_info) as $property => $value) {
            $person_info->$property = $value;
        }
        $data['person_info'] = $person_info;
        $data['employee_id'] = $employee_id;

        $modules = [];
        foreach ($this->module->get_all_modules()->getResult() as $module) {
            $module->grant = $this->employee->has_grant($module->module_id, $person_info->person_id);
            $module->menu_group = $this->employee->get_menu_group($module->module_id, $person_info->person_id);

            $modules[] = $module;
        }
        $data['all_modules'] = $modules;

        $permissions = [];
        foreach ($this->module->get_all_subpermissions()->getResult() as $permission) {    // TODO: subpermissions does not follow naming standards.
            $permission->permission_id = str_replace(' ', '_', $permission->permission_id);
            $permission->grant = $this->employee->has_grant($permission->permission_id, $person_info->person_id);

            $permissions[] = $permission;
        }
        $data['all_subpermissions'] = $permissions;

        return view('employees/form', $data);
    }

    /**
     * Inserts/updates an employee
     * @return ResponseInterface
     */
    public function postSave(int $employeeId = NEW_ENTRY): ResponseInterface
    {
        $currentUser = $this->employee->get_logged_in_employee_info();

        if ($employeeId != NEW_ENTRY) {
            $targetEmployee = $this->employee->get_info($employeeId);
            if (!$this->employee->canModifyEmployee($targetEmployee->person_id, $currentUser->person_id)) {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => lang('Employees.error_updating_admin'),
                    'id'      => NEW_ENTRY
                ]);
            }
        }

        $firstName = $this->request->getPost('first_name', FILTER_SANITIZE_FULL_SPECIAL_CHARS);    // TODO: duplicated code
        $lastName = $this->request->getPost('last_name', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
        $email = strtolower($this->request->getPost('email', FILTER_SANITIZE_EMAIL));

        // format first and last name properly
        $firstName = $this->nameize($firstName);
        $lastName = $this->nameize($lastName);

        $personData = [
            'first_name'   => $firstName,
            'last_name'    => $lastName,
            'gender'       => $this->request->getPost('gender', FILTER_SANITIZE_NUMBER_INT),
            'email'        => $email,
            'phone_number' => $this->request->getPost('phone_number', FILTER_SANITIZE_FULL_SPECIAL_CHARS),
            'address_1'    => $this->request->getPost('address_1', FILTER_SANITIZE_FULL_SPECIAL_CHARS),
            'address_2'    => $this->request->getPost('address_2', FILTER_SANITIZE_FULL_SPECIAL_CHARS),
            'city'         => $this->request->getPost('city', FILTER_SANITIZE_FULL_SPECIAL_CHARS),
            'state'        => $this->request->getPost('state', FILTER_SANITIZE_FULL_SPECIAL_CHARS),
            'zip'          => $this->request->getPost('zip', FILTER_SANITIZE_FULL_SPECIAL_CHARS),
            'country'      => $this->request->getPost('country', FILTER_SANITIZE_FULL_SPECIAL_CHARS),
            'comments'     => $this->request->getPost('comments', FILTER_SANITIZE_FULL_SPECIAL_CHARS)
        ];

        $grantsArray = [];
        $isAdmin = $this->employee->isAdmin($currentUser->person_id);

        foreach ($this->module->get_all_permissions()->getResult() as $permission) {
            $grants = [];
            $grant = $this->request->getPost('grant_' . $permission->permission_id) != null ? $this->request->getPost('grant_' . $permission->permission_id, FILTER_SANITIZE_FULL_SPECIAL_CHARS) : '';

            if ($grant == $permission->permission_id) {
                if (!$isAdmin && !$this->employee->has_grant($permission->permission_id, $currentUser->person_id)) {
                    continue;
                }
                $grants['permission_id'] = $permission->permission_id;
                $grants['menu_group'] = $this->request->getPost('menu_group_' . $permission->permission_id) != null ? $this->request->getPost('menu_group_' . $permission->permission_id, FILTER_SANITIZE_FULL_SPECIAL_CHARS) : '--';
                $grantsArray[] = $grants;
            }
        }

        $minimumGrants = ['employees', 'home', 'office'];
        $missingMinimumGrant = array_diff($minimumGrants, array_column($grantsArray, 'permission_id'));

        if ($isAdmin && $employeeId == $currentUser->person_id && !empty($missingMinimumGrant)) {
            return $this->response->setJSON([
                'success' => false,
                'message' => lang('Employees.error_cannot_remove_own_minimum_grant'),
                'id'      => $employeeId
            ]);
        }

        if (filter_var(getenv('DISALLOW_GRANT_CHANGE'), FILTER_VALIDATE_BOOLEAN)
            && $this->hasGrantsChanged($employeeId, $isAdmin, $currentUser, $grantsArray)) {
            return $this->response->setJSON([
                'success' => false,
                'message' => lang('Employees.error_grant_change_disallowed'),
                'id'      => $employeeId
            ]);
        }

        if (!empty($this->request->getPost('password')) && ENVIRONMENT != 'testing' && filter_var(getenv('DISALLOW_PASSWORD_CHANGE'), FILTER_VALIDATE_BOOLEAN)) {
            return $this->response->setJSON([
                'success' => false,
                'message' => lang('Employees.error_password_change_disallowed'),
                'id'      => $employeeId
            ]);
        }

        // Password has been changed OR first time password set
        if (!empty($this->request->getPost('password')) && ENVIRONMENT != 'testing') {
            $exploded = explode(":", $this->request->getPost('language', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
            $employeeData = [
                'username'      => $this->request->getPost('username', FILTER_SANITIZE_FULL_SPECIAL_CHARS),
                'password'      => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
                'hash_version'  => 2,
                'language_code' => $exploded[0],
                'language'      => $exploded[1]
            ];
        } else { // Password not changed
            $exploded = explode(":", $this->request->getPost('language', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
            $employeeData = [
                'username'      => $this->request->getPost('username', FILTER_SANITIZE_FULL_SPECIAL_CHARS),
                'language_code' => $exploded[0],
                'language'      => $exploded[1]
            ];

            // In the testing environment the password above is never persisted
            // (see the condition on the first branch), yet ospos_employees.password
            // is NOT NULL. When creating a new employee, supply a placeholder hash
            // so the insert succeeds and the grant-handling logic under test is
            // not masked by a constraint failure. Production behavior is unchanged.
            if (ENVIRONMENT === 'testing' && $employeeId == NEW_ENTRY) {
                $employeeData['password']     = password_hash('test-placeholder', PASSWORD_DEFAULT);
                $employeeData['hash_version'] = 2;
            }
        }

        if ($this->employee->save_employee($personData, $employeeData, $grantsArray, $employeeId)) {
            // New employee
            if ($employeeId == NEW_ENTRY) {
                return $this->response->setJSON([
                    'success' => true,
                    'message' => lang('Employees.successful_adding') . ' ' . $firstName . ' ' . $lastName,
                    'id'      => $employeeData['person_id']
                ]);
            } else { // Existing employee
                $loggedInEmployeeId = session()->get('person_id');
                if ($employeeId == $loggedInEmployeeId) {
                    session()->set('language_code', $employeeData['language_code']);
                    session()->set('language', $employeeData['language']);
                }
                return $this->response->setJSON([
                    'success' => true,
                    'message' => lang('Employees.successful_updating') . ' ' . $firstName . ' ' . $lastName,
                    'id'      => $employeeId
                ]);
            }
        } else { // Failure
            return $this->response->setJSON([
                'success' => false,
                'message' => lang('Employees.error_adding_updating') . ' ' . $firstName . ' ' . $lastName,
                'id'      => NEW_ENTRY
            ]);
        }
    }

    /**
     * Determines whether the submitted grants differ from the employee's current grants,
     * limited to the permissions the current user has authority over when not an admin.
     */
    private function hasGrantsChanged(int $employeeId, bool $isAdmin, object $currentUser, array $grantsArray): bool
    {
        $currentGrantIds = [];

        if ($employeeId != NEW_ENTRY) {
            $currentGrantIds = array_column($this->employee->get_employee_grants($employeeId), 'permission_id');

            if (!$isAdmin) {
                $currentGrantIds = array_values(array_filter(
                    $currentGrantIds,
                    fn ($permissionId) => $this->employee->has_grant($permissionId, $currentUser->person_id)
                ));
            }
        }

        $submittedGrantIds = array_column($grantsArray, 'permission_id');

        sort($currentGrantIds);
        sort($submittedGrantIds);

        return $currentGrantIds !== $submittedGrantIds;
    }

    /**
     * This deletes employees from the employees table
     * @return ResponseInterface
     */
    public function postDelete(): ResponseInterface
    {
        $employees_to_delete = $this->request->getPost('ids', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
        $current_user = $this->employee->get_logged_in_employee_info();

        if (!$this->employee->isAdmin($current_user->person_id)) {
            foreach ($employees_to_delete as $emp_id) {
                if ($this->employee->isAdmin((int)$emp_id)) {
                    return $this->response->setJSON(['success' => false, 'message' => lang('Employees.error_deleting_admin')]);
                }
            }
        }

        if ($this->employee->delete_list($employees_to_delete)) {    // TODO: this is passing a string, but delete_list expects an array
            return $this->response->setJSON([
                'success' => true,
                'message' => lang('Employees.successful_deleted') . ' ' . count($employees_to_delete) . ' ' . lang('Employees.one_or_multiple')
            ]);
        } else {
            return $this->response->setJSON(['success' => false, 'message' => lang('Employees.cannot_be_deleted')]);
        }
    }

    /**
     * Checks an employee username against the database. Used in app\Views\employees\form.php
     *
     * @param $employee_id
     * @return ResponseInterface
     * @noinspection PhpUnused
     */
    public function getCheckUsername($employee_id): ResponseInterface
    {
        $exists = $this->employee->username_exists($employee_id, $this->request->getGet('username'));
        return $this->response->setJSON(!$exists ? 'true' : 'false');
    }
}
